package servlets;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(name = "DeclineRequest", urlPatterns = {"/DeclineRequest"})
public class DeclineRequest extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String reqid = request.getParameter("id");
        String updatereq = "UPDATE request SET request_status = ? WHERE request_no = ?";
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/rental","root","");
            PreparedStatement stmt = conn.prepareStatement(updatereq);
            stmt.setString(1, "Declined");
            stmt.setInt(2, Integer.parseInt(reqid));
            stmt.executeUpdate();
            
        } catch(SQLException e){
            
        } catch(Exception e) {
            
        }
        RequestDispatcher view = request.getRequestDispatcher("DisplayRequests");
        view.forward(request, response);
    }

}
