package com;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

/**
 *
 * @author asus
 */
//@WebServlet("/PostService")
@MultipartConfig(maxFileSize = 20848820)
public class PostService extends HttpServlet {
    
    private String URL = "jdbc:mysql://localhost:3306/rental";
    private String User = "root";
    private String Pass = "";
    
    protected void doPost(HttpServletRequest request,
            HttpServletResponse response) throws ServletException, IOException {
        
        PrintWriter out = response.getWriter();
        String model=request.getParameter("model");
        String seatcap =request.getParameter("seatcap");
        String luggage=request.getParameter("luggcap");
        String aircon=request.getParameter("ac");
        String transmission=request.getParameter("transmission");
        String regno=request.getParameter("regno");
        String rate=request.getParameter("rate");
        String pickup=request.getParameter("pickup");
        String avail=request.getParameter("available");
        
        InputStream inputStream = null;
        String message = null;
        Connection con=null;
        
        Part filePart = request.getPart("picture");
        if (filePart != null) {            
            // obtains input stream of the upload file
            inputStream = filePart.getInputStream();
        }
        try {
            DriverManager.registerDriver(new com.mysql.jdbc.Driver());
            con=DriverManager.getConnection(URL, User, Pass);
                        
            String query="INSERT INTO vehicles(model, seating_capacity, luggage_capacity,air_conditioned, transmission, regno, daily_rate, picture, pickup_location,status) VALUES(?,?,?,?,?,?,?,?,?,?)";
            PreparedStatement pst = con.prepareStatement(query);
            pst.setString(1, model);
            pst.setString(2, seatcap);
            pst.setString(3, luggage);
            pst.setString(4, aircon);
            pst.setString(5, transmission);
            pst.setString(6, regno);
            pst.setString(7, rate);
            pst.setBlob(8, inputStream);
            pst.setString(9, pickup);  
            pst.setString(10, avail);  
            int row = pst.executeUpdate();
            if (row > 0) {
                out.println("<p>File uploaded and saved into database.</p>");
                response.sendRedirect("index.jsp");
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            out.print(ex);
        } 
    }
}
