$(function() {
	$('.summernote').summernote({
	  height: 500
	});
});